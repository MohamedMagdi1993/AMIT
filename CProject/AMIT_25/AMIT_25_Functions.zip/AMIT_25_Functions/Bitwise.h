

int SetBit  (int Byte , int BitPosition );
int ClearBit (int Byte , int BitPosition );
int ToggleBit (int Byte , int BitPosition );
