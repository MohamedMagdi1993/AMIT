#ifndef Arithmaic_H

#define Arithmaic_H
int sum( int x , int y );
int sub( int x , int y );
int Div( int x , int y );
int mul( int x , int y );
int Factorial (int x) ; // decleration
int x = 3 ;

#endif // Arithmaic_H
